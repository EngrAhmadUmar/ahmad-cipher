from .has_seen import UserHasSeen

check = UserHasSeen()