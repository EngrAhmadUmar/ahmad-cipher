from django.apps import AppConfig


class EncryptDecryptAppConfig(AppConfig):
    name = 'encrypt_decrypt_app'
